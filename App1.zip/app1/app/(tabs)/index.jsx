import { View, Text, Image, TextInput, StyleSheet, SafeAreaView, TouchableOpacity, ScrollView } from 'react-native';
import logo from '@/assets/images/output.png';
import trashbin from '@/assets/images/trashbin.png';
import React, { useState } from 'react';

const App = () => {
  const [newTask, setNewTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (newTask.trim()) {
      const newTaskObject = { id: Date.now(), text: newTask };
      setTasks([...tasks, newTaskObject]);
      setNewTask('');
    }
  };

  const deleteTask = (taskId) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Image source={logo} style={styles.logo} />
        <Text style={styles.text}>To-do lijst</Text>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Voer een taak in"
          placeholderTextColor={'#777879'}
          value={newTask}
          onChangeText={setNewTask}
        />
        <TouchableOpacity style={styles.voeg} onPress={addTask}>
          <Text style={styles.buttonText}>Toevoegen</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.whitebox}>
        {tasks.length === 0 ? (
          <Text style={styles.noTasksText}>Nog geen taken toegevoegd</Text>
        ) : (
          <ScrollView contentContainerStyle={styles.scrollContent}>
            {tasks.map((task) => (
              <View key={task.id} style={styles.taskRow}>
                <Text style={styles.taskText}>{task.text}</Text>
                <TouchableOpacity onPress={() => deleteTask(task.id)}>
                  <Image source={trashbin} style={styles.trashbin} />
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>
        )}
      </View>
    </SafeAreaView>
  );
};

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'dodgerblue',
    alignItems: 'center',
  },
  text: {
    fontSize: 45,
    fontWeight: '650',
    textShadowColor: 'black',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  header: {
    width: '100%',
    height: 60,
    backgroundColor: '#357bfd',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 10,
    borderRadius: 15,
    shadowOpacity: 0.3,
    shadowOffset: { height: 2, width: 2 },
    shadowColor: 'black',
  },
  whitebox: {
    height: '70%',
    width: '90%',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: 'white',
    marginTop: 20,
    borderRadius: 15,
    padding: 10,
  },
  scrollContent: {
    flexGrow: 1,
  },
  logo: {
    position: 'absolute',
    left: 10,
    height: '100%',
    width: 50,
    resizeMode: 'contain',
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 20,
    paddingHorizontal: 10,
    width: '90%',
    color: 'black',
  },
  input: {
    borderWidth: 1,
    borderColor: 'white',
    padding: 10,
    borderRadius: 5,
    flex: 1,
    marginRight: 10,
    backgroundColor: 'white',
  },
  voeg: {
    color: 'black',
    borderRadius: 5,
    height: 40,
    width: 100,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4a9bf2',
    borderColor: '#4a9bf2',
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
  },
  taskRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    width: '100%',
    backgroundColor: '#f9f9f9',
    padding: 10,
    borderRadius: 5,
  },
  taskText: {
    fontSize: 16,
    color: 'black',
  },
  trashbin: {
    height: 20,
    width: 20,
  },
  noTasksText: {
    fontSize: 18,
    color: '#777879',
    textAlign: 'center',
    marginTop: 20,
  },
});
